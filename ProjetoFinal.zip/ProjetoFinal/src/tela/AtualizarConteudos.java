package tela;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import modelo.Conteudos;
import modelo.ConteudosDAO;

public class AtualizarConteudos extends JFrame{

	

		private  DefaultTableModel modelo = new DefaultTableModel();
		private JPanel painelFundo;
		private JButton btSalvar;
		private JButton btLimpar;
		private JLabel lbTipo;
		private JLabel lbNome;
		private JLabel lbSinopse;
		private JLabel lbId;
		private JTextField txnome;
		private JTextField txId;
		private JTextField txtipo;
		private JTextField txsinopse;
		Conteudos cont;
		private  int linhaSelecionada;

		public AtualizarConteudos(DefaultTableModel md,int id, int linha) {
			super("Conteudos");
			criaJanela();
			modelo = md;
			ConteudosDAO dao = new ConteudosDAO();
			cont = dao.getConteudosById(id);
			txId.setText(Integer.toString(cont.getId()));
			txtipo.setText(cont.getTipo());
			txnome.setText(cont.getNome());
			txsinopse.setText(cont.getSinopse());
			linhaSelecionada = linha;
		}

		public void criaJanela() {
			btSalvar = new JButton("Salvar");
			btLimpar = new JButton("Limpar");
			lbTipo = new JLabel("        Tipo.:   ");
			lbNome = new JLabel("         Nome.:   ");
			lbSinopse = new JLabel("         Sinopse.:   ");
			lbId = new JLabel("         Id.:   ");
			txtipo = new JTextField();
			txnome = new JTextField();
			txsinopse = new JTextField();
			txId = new JTextField();
			txId.setEditable(true);

			painelFundo = new JPanel();
			painelFundo.setLayout(new GridLayout(5, 2, 2, 4));
			painelFundo.add(lbId);
			painelFundo.add(txId);
			painelFundo.add(lbNome);
			painelFundo.add(txnome);
			painelFundo.add(lbTipo);
			painelFundo.add(txtipo);
			painelFundo.add(lbSinopse);
			painelFundo.add(txsinopse);
			painelFundo.add(btLimpar);
			painelFundo.add(btSalvar);

			getContentPane().add(painelFundo);
			setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			setSize(300, 150);
			setVisible(true);

			btSalvar.addActionListener(new
			AtualizarConteudos.BtSalvarListener());
			btLimpar.addActionListener(new
			AtualizarConteudos.BtLimparListener());
		}

		private class BtSalvarListener implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				Conteudos c = new Conteudos();
				c.setId(Integer.parseInt(txId.getText()));
				c.setNome(txnome.getText());
				c.setTipo(txtipo.getText());
				c.setSinopse(txsinopse.getText());

				ConteudosDAO dao = new ConteudosDAO();
				dao.update(c);
				modelo.removeRow(linhaSelecionada);
				modelo.addRow(new Object[]{c.getId(),
				c.getNome(), c.getTipo(), c.getSinopse()});
				setVisible(true);
			}
		}

		private class BtLimparListener implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				txnome.setText("");
				txtipo.setText("");
				txsinopse.setText("");
			}

			

		
			
		}
	}


