package tela;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import modelo.Conteudos;
import modelo.ConteudosDAO;

public class InserirConteudos extends JFrame {


		private DefaultTableModel modelo = new DefaultTableModel();
		private JPanel painelFundo;
		private JButton btSalvar;
		private JButton btLimpar;
		private JLabel lbTipo;
		private JLabel lbNome;
		private JLabel lbSinopse;
		private JTextField txnome;
		private JTextField txtipo;
		private JTextField txsinopse;

		public InserirConteudos(DefaultTableModel md) {
			super("Conteudos");
			criaJanela();
			modelo = md;
		}

		public void criaJanela() {
			btSalvar = new JButton("Salvar");
			btLimpar = new JButton("Limpar");
			lbTipo = new JLabel("         Tipo.:   ");
			lbNome = new JLabel("        Nome.:   ");
			lbSinopse = new JLabel("        Sinopse.:   ");
			txtipo = new JTextField(10);
			txnome = new JTextField();
			txsinopse = new JTextField();

			painelFundo = new JPanel();
			painelFundo.setLayout(new GridLayout(4, 2, 2, 4));
			painelFundo.add(lbTipo);
			painelFundo.add(txtipo);
			painelFundo.add(lbNome);
			painelFundo.add(txnome);
			painelFundo.add(lbSinopse);
			painelFundo.add(txsinopse);
			painelFundo.add(btLimpar);
			painelFundo.add(btSalvar);

			getContentPane().add(painelFundo);
			setDefaultCloseOperation(DISPOSE_ON_CLOSE);
			setSize(300, 150);
			setVisible(true);
			btSalvar.addActionListener(new BtSalvarListener());
			btLimpar.addActionListener(new BtLimparListener());
		}

		private class BtSalvarListener implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				Conteudos c = new Conteudos();
				c.setTipo(txtipo.getText());
				c.setNome(txnome.getText());
				c.setSinopse(txsinopse.getText());

				ConteudosDAO dao = new ConteudosDAO();
				try {
					dao.save(c);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ListarConteudos.pesquisar(modelo);

				setVisible(false);
			}

			
		}



		private class BtLimparListener implements ActionListener {

			public void actionPerformed(ActionEvent e) {
				txtipo.setText("");
				txnome.setText("");
				txsinopse.setText("");
			}

			
		}
	}

