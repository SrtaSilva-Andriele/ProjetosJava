package tela;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import conexao.ConnectionFactory;
import modelo.Conteudos;
import modelo.ConteudosDAO;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class ListarConteudos {
	private static JTextField textID;
	private static JTextField textTipo;
	private static JTextField textNome;
	private static JTextField textSinopse;

	public static void main(String[] args) {
		
		JTable table = new JTable();
		Object[] columns = {"Id", "Tipo", "Nome", "Sinopse"};
		DefaultTableModel model  = new DefaultTableModel();
		
		JFrame frame = new JFrame("Window");
		frame.setBackground(new Color(0,0,0));
		frame.setForeground(Color.BLUE);
		frame.setBounds(100,100,438,600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().setLayout(null);
		
		
		model.setColumnIdentifiers(columns);
		table.setModel(model);
		table.setBackground(Color.black);
		table.setForeground(Color.white);
		table.setSelectionBackground(Color.red);
		table.setGridColor(Color.red);
		table.setSelectionBackground(Color.blue);
		table.setFont(new Font("Tahoma", Font.PLAIN,17));
		table.setRowHeight(30);
		table.setAutoCreateRowSorter(true);
		
		JScrollPane pane = new JScrollPane(table);
		pane.setForeground(Color.gray);
		pane.setBackground(Color.black);
		pane.setBounds(10,163,402,353);
		frame.getContentPane().add(pane);
		
		JLabel lblid = new JLabel("ID");
		lblid.setHorizontalAlignment(SwingConstants.CENTER);
		lblid.setBounds(23, 23, 46, 14);
		frame.getContentPane().add(lblid);
		
		JLabel lbltipo = new JLabel("TIPO");
		lbltipo.setHorizontalAlignment(SwingConstants.CENTER);
		lbltipo.setBounds(23, 71, 46, 14);
		frame.getContentPane().add(lbltipo);
		
		JLabel lblnome = new JLabel("NOME");
		lblnome.setHorizontalAlignment(SwingConstants.CENTER);
		lblnome.setBounds(219, 23, 46, 14);
		frame.getContentPane().add(lblnome);
		
		JLabel lblsinopse = new JLabel("SINOPSE");
		lblsinopse.setHorizontalAlignment(SwingConstants.CENTER);
		lblsinopse.setBounds(205, 71, 72, 14);
		frame.getContentPane().add(lblsinopse);
		
		textID = new JTextField();
		textID.setBounds(79, 20, 130, 20);
		frame.getContentPane().add(textID);
		textID.setColumns(10);
		
		textTipo = new JTextField();
		textTipo.setBounds(79, 68, 130, 20);
		frame.getContentPane().add(textTipo);
		textTipo.setColumns(10);
		
		textNome = new JTextField();
		textNome.setBounds(279, 20, 133, 20);
		frame.getContentPane().add(textNome);
		textNome.setColumns(10);
		
		textSinopse = new JTextField();
		textSinopse.setBounds(275, 68, 137, 20);
		frame.getContentPane().add(textSinopse);
		textSinopse.setColumns(10);
		
		JButton btnCarregar = new JButton("Carregar Dados");
		btnCarregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

try {
					Connection con = ConnectionFactory.getConnection();
					String sql = "SELECT * FROM streaming";
					
					PreparedStatement s = con.prepareStatement(sql);
					ResultSet rs = s.executeQuery();
					DefaultTableModel model = (DefaultTableModel)(table.getModel());
					model.setNumRows(0);
					
					while(rs.next()) {
						model.addRow(new Object[] {rs.getInt("id"), rs.getString("Tipo"), rs.getString("Nome"), rs.getString("Sinopse")});
					}
					rs.close();
					con.close();
				}catch(SQLException e1) {
					e1.printStackTrace();
				}

			}
		});
		btnCarregar.setBounds(251, 527, 143, 23);
		frame.getContentPane().add(btnCarregar);
		
		JButton btninserir = new JButton("Inserir");
		btninserir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Conteudos c = new Conteudos();
				c.setTipo(textTipo.getText());
				c.setNome(textNome.getText());
				c.setSinopse(textSinopse.getText());

				ConteudosDAO dao = new ConteudosDAO();
				try {
					dao.save(c);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ListarConteudos.pesquisar(model);
			}
		});
		btninserir.setBounds(10, 128, 120, 23);
		frame.getContentPane().add(btninserir);
		
		JButton btnatualizar = new JButton("Atualizar");
		btnatualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Conteudos c = new Conteudos();
				c.setId(Integer.parseInt(textID.getText()));
				c.setNome(textNome.getText());
				c.setTipo(textTipo.getText());
				c.setSinopse(textSinopse.getText());

				ConteudosDAO dao = new ConteudosDAO();
				dao.update(c);
				int row = -1;
				model.removeRow(row);
				model.addRow(new Object[]{c.getId(),
				c.getNome(), c.getTipo(), c.getSinopse()});

			}
		});
		btnatualizar.setBounds(171, 129, 120, 23);
		frame.getContentPane().add(btnatualizar);
		
		JButton btnlimpar = new JButton("Limpar");
		btnlimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textID.setText("");
				textTipo.setText("");
				textNome.setText("");
				textSinopse.setText("");
			}
		});
		btnlimpar.setBounds(323, 128, 89, 23);
		frame.getContentPane().add(btnlimpar);
		
		JButton btnDeletar = new JButton("Deletar");
		btnDeletar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

                 Conteudos conteudos = new Conteudos();
				ConteudosDAO dao = new ConteudosDAO();
				conteudos.setId(Integer.parseInt(textID.getText()));
					dao.deleteById(conteudos);
					
					

			}
		});
		btnDeletar.setBounds(20, 527, 130, 23);
		frame.getContentPane().add(btnDeletar);

		frame.setVisible(true);
	}

	protected static void pesquisar(DefaultTableModel model) {
		
		model.setNumRows(0);
		ConteudosDAO dao = new ConteudosDAO();

		for (Conteudos c : dao.getConteudos()) {
			model.addRow(new Object[]{c.getId(), c.getTipo(),
			c.getNome(), c.getSinopse()});
		}
		
		
	}
}
