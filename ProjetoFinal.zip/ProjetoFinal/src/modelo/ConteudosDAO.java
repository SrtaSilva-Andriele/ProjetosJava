package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import conexao.ConnectionFactory;

public class ConteudosDAO {

	private static final String LISTBYID = null;
	private Connection connection;
	int id;
	String tipo;
	String nome;
	String sinopse;

	public ConteudosDAO() {
		this.connection = new ConnectionFactory().getConnection();
	}

	public void save(Conteudos cont)throws Exception {
		String sql = "INSERT INTO streaming(tipo,nome,sinopse) VALUES (?, ?, ?)";
		Connection con = null;
		java.sql.PreparedStatement p = null;
		
		try {
			con = ConnectionFactory.createConnnectionToMySQL();
			p = con.prepareStatement(sql);
			PreparedStatement s = connection.prepareStatement(sql);
			
			s.setString(1, cont.getTipo());
			s.setString(2, cont.getNome());
			s.setString(3, cont.getSinopse());
			s.execute();
			JOptionPane.showMessageDialog(null, "Inserido com sucesso!");
			
		}catch (SQLException e ) {
			e.printStackTrace();
		}finally {
			
		}try {
			if(p != null) {
				con.close();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public List<Conteudos> getConteudos(){
		String sql = "SELECT * FROM streaming";
		List<Conteudos> cont = new ArrayList<>();
		Connection con = null;
		PreparedStatement p = null;
		ResultSet rs = null;
		  try {
			  con = ConnectionFactory.createConnnectionToMySQL();
			  p = con.prepareStatement(sql);
			  rs = p.executeQuery();
			  while (rs.next()) {
				 Conteudos cont1 = new Conteudos();
				  cont1.setId(rs.getInt("id"));
				  cont1.setTipo(rs.getString("tipo"));
				 cont1.setNome(rs.getString("nome"));
				  cont1.setSinopse(rs.getString("sinopse"));
				  
				  
				  cont1.add(cont1);
				  
			}
			  }catch (Exception e ) {
				  e.printStackTrace();
			  }finally {
				  
			  }
		return cont;
	}
	public void update (Conteudos conteudos) {
		String sql = "UPDATE streaming SET tipo = ?, nome = ?, sinopse = ?"+"WHERE id = ?";
		
		Connection conn = null; 
		PreparedStatement pstm = null;
		
		try {
			conn = ConnectionFactory.createConnnectionToMySQL();
			pstm = conn.prepareStatement(sql);
			
			pstm.setString(1, conteudos.getTipo());
			pstm.setString(2, conteudos.getNome());
			pstm.setString(3, conteudos.getSinopse());
			
			
			pstm.setInt(4, conteudos.getId());
			pstm.execute();
			JOptionPane.showMessageDialog(null, "Conteudo atualizado com sucesso!");

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
		}
		
		
	}
	public void deleteById(Conteudos idConteudo) {
		String sql = "DELETE  FROM streaming WHERE id = ?";
		Connection conn = null;
		PreparedStatement pstm = null;
		
		try {
			conn = ConnectionFactory.createConnnectionToMySQL();
			pstm = (PreparedStatement)conn.prepareStatement(sql);
			pstm.setInt(1, idConteudo.getId());
			pstm.execute();
			JOptionPane.showMessageDialog(null, "Excluido com sucesso!");

			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				try {
					if(pstm != null){
						pstm.close();
					}
					if(conn != null) {
						conn.close();
					}
				}catch (Exception e) {
					e.printStackTrace();
				}
			}
		
	}

	public Conteudos getConteudosById(int id) {
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		Conteudos cont = new Conteudos();
		try {
			conn = ConnectionFactory.getConnection();
			pstm = conn.prepareStatement(LISTBYID);
			pstm.setInt(1, id);
			rs = pstm.executeQuery();
			while (rs.next()) {
				cont.setId(rs.getInt("id"));
				cont.setNome(rs.getString("nome"));
				cont.setTipo(rs.getString("tipo"));
				cont.setSinopse(rs.getString("sinopse"));
			}
			
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Erro ao listar contatos" + e.getMessage());
		}
		return cont;
	}
}
